-- FireTracker Database Schema
-- Creates tables for user management, LoRaWAN devices, and sensor readings

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- LoRaWAN devices table
CREATE TABLE IF NOT EXISTS lora_devices (
  device_id VARCHAR(100) PRIMARY KEY,
  owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  friendly_name VARCHAR(255) NOT NULL,
  static_location JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sensor readings table
CREATE TABLE IF NOT EXISTS sensor_readings (
  reading_id BIGSERIAL PRIMARY KEY,
  device_id VARCHAR(100) NOT NULL REFERENCES lora_devices(device_id) ON DELETE CASCADE,
  timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  temperature_c NUMERIC(5, 2),
  humidity_percent NUMERIC(5, 2),
  latitude NUMERIC(10, 6),
  longitude NUMERIC(10, 6),
  is_alert BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_lora_devices_owner_id ON lora_devices(owner_id);
CREATE INDEX IF NOT EXISTS idx_sensor_readings_device_id ON sensor_readings(device_id);
CREATE INDEX IF NOT EXISTS idx_sensor_readings_timestamp ON sensor_readings(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_sensor_readings_is_alert ON sensor_readings(is_alert) WHERE is_alert = TRUE;
