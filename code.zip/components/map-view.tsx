"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin } from "lucide-react"
import Image from "next/image"

export function MapView() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="h-5 w-5" />
          Device Locations
        </CardTitle>
        <CardDescription>Real-time fire monitoring device map</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="relative w-full h-96 bg-muted rounded-lg overflow-hidden">
          <Image src="/map-with-fire-monitoring-devices.jpg" alt="Fire monitoring device map" fill className="object-cover" />
          <div className="absolute inset-0 flex items-center justify-center bg-black/50">
            <div className="text-center">
              <p className="text-white text-sm font-medium">Integrate with Leaflet or Mapbox</p>
              <p className="text-white/70 text-xs mt-1">Add devices to see their locations</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
