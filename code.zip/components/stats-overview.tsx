"use client"

import type React from "react"

import { Card, CardContent } from "@/components/ui/card"
import { Activity, AlertTriangle, Thermometer, Droplets } from "lucide-react"

interface StatCard {
  label: string
  value: string
  icon: React.ReactNode
  trend?: string
}

export function StatsOverview() {
  const stats: StatCard[] = [
    {
      label: "Active Devices",
      value: "0",
      icon: <Activity className="h-4 w-4" />,
    },
    {
      label: "Alerts",
      value: "0",
      icon: <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />,
    },
    {
      label: "Avg Temperature",
      value: "--",
      icon: <Thermometer className="h-4 w-4" />,
    },
    {
      label: "Avg Humidity",
      value: "--",
      icon: <Droplets className="h-4 w-4" />,
    },
  ]

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, idx) => (
        <Card key={idx}>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <p className="text-2xl font-bold mt-2">{stat.value}</p>
              </div>
              <div className="h-12 w-12 rounded-lg bg-muted flex items-center justify-center">{stat.icon}</div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
