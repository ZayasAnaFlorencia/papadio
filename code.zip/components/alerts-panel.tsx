"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, Activity, Loader2 } from "lucide-react"

interface Alert {
  reading_id: number
  device_id: string
  temperature_c: number
  humidity_percent: number
  timestamp: string
}

export function AlertsPanel() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchAlerts()
    const interval = setInterval(fetchAlerts, 30000) // Poll every 30 seconds
    return () => clearInterval(interval)
  }, [])

  const fetchAlerts = async () => {
    try {
      // In a real app, this would fetch from an API endpoint
      // For now, we'll show a placeholder
      setAlerts([])
    } catch (err) {
      console.error("[v0] fetchAlerts error:", err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="border-amber-200 dark:border-amber-900">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              Active Alerts
            </CardTitle>
            <CardDescription>Fire risk notifications from your devices</CardDescription>
          </div>
          <Badge variant="outline">{alerts.length}</Badge>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-4 w-4 animate-spin" />
          </div>
        ) : alerts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Activity className="h-8 w-8 text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">No active alerts</p>
            <p className="text-xs text-muted-foreground mt-1">All systems operating normally</p>
          </div>
        ) : (
          <div className="space-y-3">
            {alerts.map((alert) => (
              <div
                key={alert.reading_id}
                className="rounded-lg border border-amber-200 bg-amber-50 p-3 dark:border-amber-900 dark:bg-amber-950/30"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium text-sm text-amber-900 dark:text-amber-100">
                      Device {alert.device_id.slice(-8)}
                    </p>
                    <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
                      Temp: {alert.temperature_c}°C | Humidity: {alert.humidity_percent}%
                    </p>
                  </div>
                  <Badge variant="destructive" className="text-xs">
                    ALERT
                  </Badge>
                </div>
                <p className="text-xs text-amber-600 dark:text-amber-400 mt-2">
                  {new Date(alert.timestamp).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
