"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { AlertCircle, CheckCircle2, Loader2 } from "lucide-react"

export function AddDeviceForm() {
  const [deviceId, setDeviceId] = useState("")
  const [friendlyName, setFriendlyName] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSuccess(false)

    if (!deviceId.trim() || !friendlyName.trim()) {
      setError("Both Device ID and Name are required")
      return
    }

    try {
      setLoading(true)
      const response = await fetch("/api/dispositivos", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-user-id": "user-123", // Replace with actual user ID from auth
        },
        body: JSON.stringify({
          deviceId: deviceId.toUpperCase(),
          friendlyName,
        }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Failed to add device")
      }

      setSuccess(true)
      setDeviceId("")
      setFriendlyName("")

      // Reset success message after 3 seconds
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error")
      console.error("[v0] handleSubmit error:", err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add New Device</CardTitle>
        <CardDescription>Link a LoRaWAN device to your account</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="flex items-center gap-2 rounded-md bg-destructive/10 p-3 text-destructive">
              <AlertCircle className="h-4 w-4" />
              <span className="text-sm">{error}</span>
            </div>
          )}

          {success && (
            <div className="flex items-center gap-2 rounded-md bg-green-50 p-3 text-green-700 dark:bg-green-900/20 dark:text-green-400">
              <CheckCircle2 className="h-4 w-4" />
              <span className="text-sm">Device added successfully!</span>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="device-id">Device ID (DevEUI)</Label>
            <Input
              id="device-id"
              placeholder="e.g., AABBCCDD11223344"
              value={deviceId}
              onChange={(e) => setDeviceId(e.target.value)}
              disabled={loading}
              maxLength={100}
            />
            <p className="text-xs text-muted-foreground">The unique identifier of your LoRaWAN device</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="friendly-name">Friendly Name</Label>
            <Input
              id="friendly-name"
              placeholder="e.g., Garden Sensor"
              value={friendlyName}
              onChange={(e) => setFriendlyName(e.target.value)}
              disabled={loading}
              maxLength={255}
            />
            <p className="text-xs text-muted-foreground">A descriptive name for your device</p>
          </div>

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Adding Device...
              </>
            ) : (
              "Add Device"
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
