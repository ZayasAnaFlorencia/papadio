"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle, Loader2, Trash2 } from "lucide-react"

interface Device {
  device_id: string
  friendly_name: string
  static_location?: { lat: number; lng: number }
  created_at: string
}

export function DeviceList() {
  const [devices, setDevices] = useState<Device[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchDevices()
  }, [])

  const fetchDevices = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/dispositivos", {
        headers: { "x-user-id": "user-123" }, // Replace with actual user ID from auth
      })

      if (!response.ok) {
        throw new Error("Failed to fetch devices")
      }

      const data = await response.json()
      setDevices(data.devices || [])
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error")
      console.error("[v0] fetchDevices error:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteDevice = async (deviceId: string) => {
    try {
      const response = await fetch(`/api/dispositivos/${deviceId}`, {
        method: "DELETE",
        headers: { "x-user-id": "user-123" },
      })

      if (!response.ok) {
        throw new Error("Failed to delete device")
      }

      setDevices(devices.filter((d) => d.device_id !== deviceId))
    } catch (err) {
      console.error("[v0] handleDeleteDevice error:", err)
      setError(err instanceof Error ? err.message : "Failed to delete device")
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>My Devices</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="animate-spin" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>My Devices</CardTitle>
        <CardDescription>
          {devices.length === 0 ? "No devices linked yet" : `${devices.length} device(s) linked`}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <div className="mb-4 flex items-center gap-2 rounded-md bg-destructive/10 p-3 text-destructive">
            <AlertCircle className="h-4 w-4" />
            <span className="text-sm">{error}</span>
          </div>
        )}

        {devices.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">No devices linked yet. Add a device to get started.</p>
        ) : (
          <div className="space-y-4">
            {devices.map((device) => (
              <div
                key={device.device_id}
                className="flex items-center justify-between rounded-lg border p-4 hover:bg-muted/50"
              >
                <div className="flex-1">
                  <h3 className="font-medium">{device.friendly_name}</h3>
                  <p className="text-sm text-muted-foreground">ID: {device.device_id}</p>
                  <p className="text-xs text-muted-foreground">
                    Added: {new Date(device.created_at).toLocaleDateString()}
                  </p>
                </div>
                <Button variant="ghost" size="sm" onClick={() => handleDeleteDevice(device.device_id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
