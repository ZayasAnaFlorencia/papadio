import { AddDeviceForm } from "@/components/add-device-form"
import { DeviceList } from "@/components/device-list"

export default function DevicesPage() {
  return (
    <main className="min-h-screen bg-background p-4 sm:p-8">
      <div className="mx-auto max-w-2xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Device Management</h1>
          <p className="text-muted-foreground mt-2">Link and manage your LoRaWAN fire monitoring devices</p>
        </div>

        <div className="space-y-6">
          <AddDeviceForm />
          <DeviceList />
        </div>
      </div>
    </main>
  )
}
