import { AuthForm } from "@/components/auth-form"
import { Flame } from "lucide-react"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-background to-muted flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Flame className="h-8 w-8 text-orange-600 dark:text-orange-400" />
            <h1 className="text-3xl font-bold">FireTracker</h1>
          </div>
          <p className="text-muted-foreground">Real-time wildfire monitoring with LoRaWAN sensors</p>
        </div>

        {/* Auth Form */}
        <AuthForm />

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-xs text-muted-foreground">
            Monitor fire risks across your properties with advanced LoRaWAN technology
          </p>
        </div>
      </div>
    </main>
  )
}
