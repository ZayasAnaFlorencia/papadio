import { StatsOverview } from "@/components/stats-overview"
import { MapView } from "@/components/map-view"
import { AlertsPanel } from "@/components/alerts-panel"
import { Button } from "@/components/ui/button"
import { Link } from "lucide-react"

export default function DashboardPage() {
  return (
    <main className="min-h-screen bg-background p-4 sm:p-8">
      <div className="mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Fire Monitoring Dashboard</h1>
          <p className="text-muted-foreground mt-2">Real-time monitoring of your LoRaWAN fire detection devices</p>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <Button>
            <Link className="h-4 w-4 mr-2" />
            Manage Devices
          </Button>
        </div>

        {/* Stats Overview */}
        <div className="mb-8">
          <StatsOverview />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <MapView />
          </div>
          <div>
            <AlertsPanel />
          </div>
        </div>
      </div>
    </main>
  )
}
