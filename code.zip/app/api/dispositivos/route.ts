import { neon } from "@neondatabase/serverless"
import { type NextRequest, NextResponse } from "next/server"

const sql = neon(process.env.DATABASE_URL || "")

async function getAuthenticatedUserId(request: NextRequest): Promise<string> {
  // In production, this would validate a JWT or session
  // For now, we'll get it from a custom header for testing
  const userId = request.headers.get("x-user-id")
  if (!userId) {
    throw new Error("User not authenticated")
  }
  return userId
}

// POST: Link a LoRaWAN device to the current user
export async function POST(request: NextRequest) {
  try {
    const userId = await getAuthenticatedUserId(request)
    const { deviceId, friendlyName, staticLocation } = await request.json()

    if (!deviceId || !friendlyName) {
      return NextResponse.json({ error: "deviceId and friendlyName are required" }, { status: 400 })
    }

    // Check if device already exists
    const existingDevice = await sql("SELECT owner_id FROM lora_devices WHERE device_id = $1", [deviceId])

    if (existingDevice.length > 0) {
      if (existingDevice[0].owner_id !== userId) {
        return NextResponse.json({ error: "Device already registered by another user" }, { status: 409 })
      }
      // Device already linked to this user
      return NextResponse.json({ message: "Device already linked", device: existingDevice[0] }, { status: 200 })
    }

    // Insert new device
    const result = await sql(
      `INSERT INTO lora_devices (device_id, owner_id, friendly_name, static_location)
       VALUES ($1, $2, $3, $4)
       RETURNING device_id, owner_id, friendly_name, static_location, created_at`,
      [deviceId, userId, friendlyName, staticLocation || null],
    )

    return NextResponse.json({ message: "Device linked successfully", device: result[0] }, { status: 201 })
  } catch (error) {
    console.error("[v0] POST /api/dispositivos error:", error)
    return NextResponse.json({ error: "Failed to link device" }, { status: 500 })
  }
}

// GET: List all devices for the current user
export async function GET(request: NextRequest) {
  try {
    const userId = await getAuthenticatedUserId(request)

    const devices = await sql(
      `SELECT device_id, friendly_name, static_location, created_at
       FROM lora_devices
       WHERE owner_id = $1
       ORDER BY created_at DESC`,
      [userId],
    )

    return NextResponse.json({ devices }, { status: 200 })
  } catch (error) {
    console.error("[v0] GET /api/dispositivos error:", error)
    return NextResponse.json({ error: "Failed to fetch devices" }, { status: 500 })
  }
}
