import { neon } from "@neondatabase/serverless"
import { type NextRequest, NextResponse } from "next/server"

const sql = neon(process.env.DATABASE_URL || "")

async function getAuthenticatedUserId(request: NextRequest): Promise<string> {
  const userId = request.headers.get("x-user-id")
  if (!userId) {
    throw new Error("User not authenticated")
  }
  return userId
}

// DELETE: Unlink a device from the current user
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ deviceId: string }> }) {
  try {
    const userId = await getAuthenticatedUserId(request)
    const { deviceId } = await params

    // Verify ownership and delete
    const result = await sql(
      `DELETE FROM lora_devices
       WHERE device_id = $1 AND owner_id = $2
       RETURNING device_id`,
      [deviceId, userId],
    )

    if (result.length === 0) {
      return NextResponse.json({ error: "Device not found or unauthorized" }, { status: 404 })
    }

    return NextResponse.json({ message: "Device unlinked successfully" }, { status: 204 })
  } catch (error) {
    console.error("[v0] DELETE /api/dispositivos error:", error)
    return NextResponse.json({ error: "Failed to unlink device" }, { status: 500 })
  }
}

// GET: Get details for a specific device
export async function GET(request: NextRequest, { params }: { params: Promise<{ deviceId: string }> }) {
  try {
    const userId = await getAuthenticatedUserId(request)
    const { deviceId } = await params

    const device = await sql(
      `SELECT device_id, friendly_name, static_location, created_at
       FROM lora_devices
       WHERE device_id = $1 AND owner_id = $2`,
      [deviceId, userId],
    )

    if (device.length === 0) {
      return NextResponse.json({ error: "Device not found" }, { status: 404 })
    }

    return NextResponse.json({ device: device[0] }, { status: 200 })
  } catch (error) {
    console.error("[v0] GET /api/dispositivos/[deviceId] error:", error)
    return NextResponse.json({ error: "Failed to fetch device" }, { status: 500 })
  }
}
