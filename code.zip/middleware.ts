import { type NextRequest, NextResponse } from "next/server"

const protectedRoutes = ["/dashboard", "/devices"]

export function middleware(request: NextRequest) {
  const pathname = request.nextUrl.pathname

  // Check if the route is protected
  const isProtectedRoute = protectedRoutes.some((route) => pathname.startsWith(route))

  if (isProtectedRoute) {
    // In production, check for a valid authentication token/session
    const userId = request.headers.get("x-user-id")

    if (!userId) {
      // Redirect to home page if not authenticated
      return NextResponse.redirect(new URL("/", request.url))
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/dashboard/:path*", "/devices/:path*"],
}
